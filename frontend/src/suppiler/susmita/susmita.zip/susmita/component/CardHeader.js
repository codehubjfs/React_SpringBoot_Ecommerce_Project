import React from 'react';

function CardHeader() {
  return (
    <div>
      <h5 style={{ fontSize: '22px', color: 'black', textAlign: 'center', }}><b>Why Suppliers Sell on Horizon?</b></h5>
      <br></br>

    </div>
  );
}

export default CardHeader;
