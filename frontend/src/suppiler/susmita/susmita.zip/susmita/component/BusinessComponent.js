import React from 'react';
import MainContent from './MainContent'; // Make sure to import MainContent from its correct file path
import growbusiness1 from '../assets/images/growbusiness1.jpg';

function BusinessComponent() {
  const title = "Selling Tools";
  const subtitle = "Join thousands of successful sellers";
  const description = `
    Tools to help you grow your business and reach new customers. 
    Our platform offers a suite of features designed to streamline your sales process 
    and increase your reach. With advanced analytics, marketing tools, 
    and customer management features, you'll have everything you need to succeed.
  `;

  return (
    <MainContent
      title={title}
      subtitle={subtitle}
      description={description}
      imageUrl={growbusiness1}
    />
  );
}

export default BusinessComponent;
