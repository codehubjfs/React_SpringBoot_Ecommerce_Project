import React from "react";
import "../App.css"; // Import CSS file for styling

function PhoneNumberInput() {
  return (
    <div>
      <button className="ui-rounded-button" style={{ backgroundColor: 'black', color: 'white' }}>Start Selling</button>
    </div>
  );
}

export default PhoneNumberInput;
