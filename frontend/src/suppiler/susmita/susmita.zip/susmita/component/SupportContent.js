import '../App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeadset } from '@fortawesome/free-solid-svg-icons';

function SupportContent() {
  return (
    <div className="col-md-5">
      <div className="ui-content">
        <h2 id="ui-support">
          <FontAwesomeIcon icon={faHeadset} /> Horizon Supplier Support – <span className="ui-availability">Available 24/7</span>
        </h2>
        <p className="support-description">
          Our dedicated support team is here to help you with any inquiries or issues you might have. Whether it's product information, order status, or technical support, we're available around the clock to assist you.
        </p>
        
      </div>
    </div>
  );
}

export default SupportContent;
