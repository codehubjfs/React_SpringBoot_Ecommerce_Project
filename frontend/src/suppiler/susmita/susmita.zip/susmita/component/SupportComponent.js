import React from 'react';
import SupportContent from './SupportContent';
import ContactContent from './ContactContent';
function SupportComponent() {
  return (
    <div className="ui-container" style={{marginBottom:'0px'}}>
      <div className="row">
        <SupportContent />
        <ContactContent />
      </div>
    </div>
  );
}

export default SupportComponent;